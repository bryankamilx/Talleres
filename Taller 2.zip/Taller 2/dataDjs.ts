import { DJ } from "./dj.js";

export const djs: DJ[] = [
new DJ(12, 'DJ Resonancia', 'Marco Resuena', 'Vibraciones Ocultas', 'Un DJ que conecta con la esencia del techno a través de sonidos profundos y resonantes.', 525870, 10, 'Techno'),
new DJ(13, 'DJ Pulsar', 'Lena Púlsar', 'Latido Cósmico', 'Una DJ que ilumina la pista de baile con ritmos pulsantes y energía estelar.', 226991, 2, 'Techno'),
new DJ(14, 'DJ Núcleo', 'Nico Nucleótido', 'Epicentro', 'Un DJ cuyo estilo se centra en el núcleo duro del techno, con beats que hacen temblar el suelo.', 155642, 1, 'Techno'),
new DJ(15, 'DJ Vórtex', 'Valeria Vortex', 'Espiral Infinita', 'Una DJ que crea un torbellino de sonidos hipnóticos que envuelven a la audiencia.', 275195, 5, 'Techno'),
new DJ(16, 'DJ Neutrón', 'Norman Neutrino', 'Colisión Subatómica', 'Un DJ que fusiona partículas de sonido para crear explosiones rítmicas que desafían la física.', 1244523, 5, 'Techno'),

];

export const data = djs.map(unDj => new DJ(unDj.id, unDj.nombreArtistico, unDj.nombreLegal, unDj.hit, unDj.descripcion, unDj.seguidores, unDj.añosActividad, unDj.genero));
