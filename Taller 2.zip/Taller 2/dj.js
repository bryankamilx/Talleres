var DJ = /** @class */ (function () {
    function DJ(id, nombreArtistico, nombreLegal, hit, descripcion, seguidores, añosActividad, genero) {
        this.id = id;
        this.nombreArtistico = nombreArtistico;
        this.nombreLegal = nombreLegal;
        this.hit = hit;
        this.descripcion = descripcion;
        this.seguidores = seguidores;
        this.añosActividad = añosActividad;
        this.genero = genero;
    }
    DJ.prototype.getId = function () {
        return this.id;
    };
    DJ.prototype.getNombreArtistico = function () {
        return this.nombreArtistico;
    };
    DJ.prototype.getNombreLegal = function () {
        return this.nombreLegal;
    };
    DJ.prototype.getHit = function () {
        return this.hit;
    };
    DJ.prototype.getDescripcion = function () {
        return this.descripcion;
    };
    DJ.prototype.getSeguidores = function () {
        return this.seguidores;
    };
    DJ.prototype.getAñosActividad = function () {
        return this.añosActividad;
    };
    DJ.prototype.getGenero = function () {
        return this.genero;
    };
    return DJ;
}());
export { DJ };
