import {data} from './dataDjs.js';
import {DJ} from './dj.js';

console.log("El archivo main.js se ha cargado correctamente");

let djsTable: HTMLElement = document.getElementById("djs-table")!;
let divAverage: HTMLElement = document.getElementById("average")!;


mostrarDatosDJs(data);
mostrarAverage(data);

function mostrarDatosDJs(djs: DJ[]): void {
    for (let dj of djs) {
        let row = document.createElement("tr");
        row.innerHTML = `<td><b>${dj.getId()}</b></td>
        <td>${dj.getNombreArtistico()}</a></td>
        <td>${dj.getHit()}</td>
        <td>${dj.getSeguidores()}</td>`;
        djsTable.appendChild(row);
    }
}

function mostrarAverage(djr : DJ[]){
    let average = 0;
    for(let dj of djr){
        average += dj.getSeguidores();
    }
    average = average/djr.length;
    divAverage.innerHTML = `<p><b>Promedio seguidores de DJs invitados: </b>${average}</p>`;
}


