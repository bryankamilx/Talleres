import { data } from './dataDjs.js';
console.log("El archivo main.js se ha cargado correctamente");
var djsTable = document.getElementById("djs-table");
var divAverage = document.getElementById("average");
mostrarDatosDJs(data);
mostrarAverage(data);
function mostrarDatosDJs(djs) {
    for (var _i = 0, djs_1 = djs; _i < djs_1.length; _i++) {
        var dj = djs_1[_i];
        var row = document.createElement("tr");
        row.innerHTML = "<td><b>".concat(dj.getId(), "</b></td>\n        <td>").concat(dj.getNombreArtistico(), "</a></td>\n        <td>").concat(dj.getHit(), "</td>\n        <td>").concat(dj.getSeguidores(), "</td>");
        djsTable.appendChild(row);
    }
}
function mostrarAverage(djr) {
    var average = 0;
    for (var _i = 0, djr_1 = djr; _i < djr_1.length; _i++) {
        var dj = djr_1[_i];
        average += dj.getSeguidores();
    }
    average = average / djr.length;
    divAverage.innerHTML = "<p><b>Promedio seguidores de DJs invitados: </b>".concat(average, "</p>");
}
