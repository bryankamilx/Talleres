export class DJ {
    id: number;
    nombreArtistico: string;
    nombreLegal: string;
    hit: string;
    descripcion: string;
    seguidores: number;
    añosActividad: number;
    genero: string;

    constructor(id: number, nombreArtistico: string, nombreLegal: string, hit: string, descripcion: string, seguidores: number, añosActividad: number, genero: string) {
        this.id = id;
        this.nombreArtistico = nombreArtistico;
        this.nombreLegal = nombreLegal;
        this.hit = hit;
        this.descripcion = descripcion;
        this.seguidores = seguidores;
        this.añosActividad = añosActividad;
        this.genero = genero;
    }

    getId(): number {
        return this.id;
    }
    getNombreArtistico(): string {
        return this.nombreArtistico;
    }
    getNombreLegal(): string {
        return this.nombreLegal;
    }
    getHit(): string {
        return this.hit;
    }
    getDescripcion(): string {
        return this.descripcion;
    }
    getSeguidores(): number {
        return this.seguidores;
    }
    getAñosActividad(): number {
        return this.añosActividad;
    }
    getGenero(): string {
        return this.genero;
    }
}
